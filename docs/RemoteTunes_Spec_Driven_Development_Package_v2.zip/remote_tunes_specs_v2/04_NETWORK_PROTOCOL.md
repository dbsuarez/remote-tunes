# RemoteTunes — Network Protocol (v2)

Same JSON protocol for local WebSocket and Supabase Realtime.

## Envelope
```json
{"type":"command","sessionId":"uuid","requestId":"uuid","payload":{}}
```

## Types
hello, pairing_request, pairing_code, pairing_result, command, command_result, state, library_request, library_response, error, ping, pong.

## Pairing
Controller sends pairing_request. Player shows code (6 digits, 5 min). Controller sends pairing_code. Player returns pairing_result with session token.

## Commands
Actions: play, pause, toggle, next, previous, stop, seek, setVolume, playUrl, playSong, queueSong, getQueue, removeQueueItem, moveQueueItem, clearQueue, setRepeatMode, setShuffle.

Example play:
```json
{"type":"command","sessionId":"s","requestId":"r","payload":{"action":"play"}}
```

Seek:
```json
{"type":"command","sessionId":"s","requestId":"r","payload":{"action":"seek","positionSeconds":45}}
```

Volume:
```json
{"type":"command","sessionId":"s","requestId":"r","payload":{"action":"setVolume","volume":0.75}}
```

PlayUrl:
```json
{"type":"command","sessionId":"s","requestId":"r","payload":{"action":"playUrl","url":"https://example.com/song.mp3","title":"Song"}}
```

## State
```json
{"type":"state","sessionId":"s","requestId":"","payload":{"title":"Song","artist":"Artist","positionSeconds":42,"durationSeconds":210,"isPlaying":true,"queueIndex":3,"queueLength":12,"volume":0.8,"repeatMode":"off","shuffleEnabled":false,"source":"local_file"}}
```

## Errors
INVALID_MESSAGE, UNSUPPORTED_PROTOCOL, NOT_PAIRED, INVALID_SESSION, SESSION_REPLACED, INVALID_ACTION, INVALID_CODE, INVALID_URL, URL_UNREACHABLE, FILE_NOT_FOUND, UNSUPPORTED_FORMAT, PLAYBACK_FAILED, INVALID_POSITION, QUEUE_EMPTY, PERMISSION_DENIED, INTERNAL_ERROR.

## Rules
- Every command gets command_result or error.
- Player sends full state after successful command.
- Unknown types/fields ignored.
- Protocol version checked in hello.
