# Phase 6 — Polish

## Scope
- Album art.
- Better queue UI.
- Drag-and-drop reorder.
- Playlists.
- Favorites.
- Recently played.
- Search.
- Sleep timer.
- Playback speed.
- Diagnostics.
- App icon/splash.

## Acceptance
- Features work.
- App remains offline-first with optional online.
